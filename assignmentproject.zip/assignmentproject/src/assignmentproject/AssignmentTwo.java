package assignmentproject;

import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class AssignmentTwo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AssignmentImplementation a = new AssignmentImplementation();
		System.out.println("Enter the size of array");
		Scanner sc = new Scanner(System.in);
		int size=sc.nextInt();
		String[] arr= new String[size];
		for(int i =0;i<size;i++)
		{
			System.out.println("Enter the element in array string:");
			arr[i]=sc.next();
			//arr[i]="balayya";
		}
		System.out.println("Problem-01");
		Map<String,Integer> m1 = a.countOfKeys(arr);
		for (String name : m1.keySet())
            System.out.print( name +"-"+m1.get(name)+" ");
		System.out.println();
		//System.out.println("Output"+a.countOfKeys(arr));
		System.out.println("Problem-02");
		System.out.println("Output"+a.firstLetterKey(arr));
		System.out.println("Enter the Integer array size ");
		int sizee = sc.nextInt();
		int argss[] = new int[sizee];
		for(int k=0;k<sizee;k++)
		{
			System.out.println("Enter the element");
			argss[k]=sc.nextInt();
			System.out.println(argss[k]);
			
		}
		System.out.println();
		System.out.println("Problem-03");
		System.out.println(a.setIncreasing(argss));
		System.out.println("Enter the size of arraylist:");
		int len= sc.nextInt();
		//ArrayList<String> al=new ArrayList<String>();
		ArrayList<String> cars = new ArrayList<String>();
		for(int i =0;i<len;i++)
		{
			System.out.println("enter the ele:");
			String t=sc.next();
			cars.add(t);
			
		}
		System.out.println("Problem-04");
		System.out.println(a.removeDuplicates(cars));
		System.out.println("Problem-05");
		System.out.println(a.formingKeysValues(cars));
		System.out.println("Problem-06");
		ArrayList<String> ca = new ArrayList<String>();
		System.out.println("Enter the size of the array:");
		int derr=sc.nextInt();
		for(int i=0;i<derr;i++)
		{
			System.out.println("enter the ele:");
			ca.add(sc.next());
		}
		System.out.println(a.assigningTrueAndFalse(ca));

	}

}
