package assignmentproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class AssignmentImplementation {
	public Map<String,Integer> countOfKeys(String[] a)
	{
		Map<String,Integer> y = new HashMap<>();
		for(String x:a)
		{
			//y.computeIfAbsent(x, y.put(x, 1));
			if(y.containsKey(x))
			{
				Integer t = y.get(x);
				y.put(x,t+1 );
			}
			else
			{
				y.put(x, 1);
			}
			
		}
		
		return y;
		
	}
	public Map<String,String> firstLetterKey(String[] args)
	{
		Map<String,String> s2= new HashMap<>();
		for(String s: args)
		{
			if(s2.containsKey(s.substring(0,1))) {
				String a=s2.get(s.substring(0,1));
				a= a+s;
				s2.put(s.substring(0,1), a);
				
			}
			else
			{
				s2.put(s.substring(0,1), s);
			}
		}
		return s2;
		
	}
/**
 * @param arr
 * @return
 */
public Set<Integer> setIncreasing(int[] arr)
{
	int count =0;
	Set<Integer> s=new HashSet<Integer>();
	for(int i=0;i<arr.length;i++)
	{ if(arr[i]==0)
	 {
	    s.add(1);	
     	}
	else
	{
		if(s.contains(arr[i]))
		{
			if(i!=0 && arr[i-1]==arr[i])
			{
				count= count+1;
				s.add(arr[i]+count);
				
			}
			else
			{
				s.add(arr[i]+1);
			}
		}
		else
		{
			s.add(arr[i]);
		}
	}
	}
	
	return s;
}
public ArrayList<String> removeDuplicates(ArrayList<String> arr)
{
	ArrayList<String> arr2 = new ArrayList<String>();
	String a=null;
	for(String i:arr)
	{
		a="";
		for(int j =0;j<i.length();j++)
		{
			String x=String.valueOf(i.charAt(j));
			if(a.contains(x))
			{
				//System.out.println("if");
			}
			else
			{
				a=a+x;
				//System.out.println(a);
				
			}
			
		}
		arr2.add(a);
		
	}
	return arr2;
	
}
public Map<String,String> formingKeysValues(ArrayList<String> arr)
{
	Map<String,String> m =new HashMap<>();
	for(String i:arr)
	{
	   	m.put(String.valueOf(i.charAt(0)), String.valueOf(i.charAt(i.length()-1)));
	}
	return m;
}
public Map<String,Boolean> assigningTrueAndFalse(ArrayList<String> arr)
{
	Map<String,Boolean> m= new HashMap();
	for(String i: arr)
	{
		if(m.containsKey(i))
		{
			m.put(i, true);
		}
		else
		{
			m.put(i, false);
		}
	}
	return m;
	
}


}
